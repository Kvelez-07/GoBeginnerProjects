package main

import (
	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/logger"
	"github.com/gofiber/fiber/v2/middleware/requestid"
	"github.com/google/uuid"
)

type User struct {
	Id        string `json:"id"`
	FirstName string `json:"first_name"`
	LastName  string `json:"last_name"`
}

func main() {
	app := fiber.New()

	// Middleware
	app.Use(logger.New()) // Logger middleware

	// Routes
	app.Get("/", func(c *fiber.Ctx) error {
		return c.SendString("Go Fiber!")
	})

	// Prefix groups
	app.Use(requestid.New())
	userGroup := app.Group("/user")   // Create a new group with prefix "/user"
	adminGroup := app.Group("/admin") // Create a new group with prefix "/admin"

	// GET
	app.Get("/hello", handleHello)  // Handle GET requests to "/"
	adminGroup.Get("", handleAdmin) // Handle GET requests to "/admin"
	userGroup.Get("", handleUser)   // Handle GET requests to "/user"

	// POST
	userGroup.Post("", handleCreateUser) // Handle POST requests to "/user"

	app.Listen(":3000") // Start server on http://localhost:3000
}

func handleHello(c *fiber.Ctx) error {
	return c.SendString("Hello, World!")
}

func handleAdmin(c *fiber.Ctx) error {
	return c.SendString("Hello, Admin!")
}

func handleUser(c *fiber.Ctx) error {
	user := User{
		FirstName: "John",
		LastName:  "Doe",
	}
	return c.Status(fiber.StatusOK).JSON(user)
}

func handleCreateUser(c *fiber.Ctx) error {
	user := new(User)

	if err := c.BodyParser(user); err != nil {
		return err
	}

	user.Id = uuid.New().String()

	return c.Status(fiber.StatusOK).JSON(user)
}
