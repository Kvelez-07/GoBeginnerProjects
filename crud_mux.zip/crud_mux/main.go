package main

import (
	"crud_mux/models"
	"fmt"
	"log"
	"net/http"

	"github.com/gorilla/mux"
)

func main() {
	fmt.Println("Listening at http://localhost:8080")
	router := mux.NewRouter().StrictSlash(true)
	router.HandleFunc("/cars/{id}", models.ReturnCarById).Methods("GET")
	router.HandleFunc("/cars", models.ReturnAllCars).Methods("GET")
	router.HandleFunc("/cars", models.CreateCar).Methods("POST")
	router.HandleFunc("/cars/{id}", models.UpdateCar).Methods("PUT")
	router.HandleFunc("/cars/{id}", models.DeleteCar).Methods("DELETE")
	router.HandleFunc("/cars", models.DeleteAllCars).Methods("DELETE")
	log.Fatal(http.ListenAndServe(":8080", router))
}
