package models

import (
	"encoding/json"
	"net/http"
	"strconv"

	"github.com/gorilla/mux"
)

type Vehicle struct {
	Id    int    `json:"id"`
	Make  string `json:"make"`
	Model string `json:"model"`
	Year  int    `json:"year"`
	Price int    `json:"price"`
}

var Vehicles = []Vehicle{
	{Id: 1, Make: "Toyota", Model: "Camry", Year: 2020, Price: 50000},
	{Id: 2, Make: "Honda", Model: "Civic", Year: 2021, Price: 60000},
	{Id: 3, Make: "Ford", Model: "Mustang", Year: 2022, Price: 70000},
}

func ReturnAllCars(w http.ResponseWriter, r *http.Request) {
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(Vehicles)
}

func ReturnCarById(w http.ResponseWriter, r *http.Request) {
	params := mux.Vars(r)
	for _, vehicle := range Vehicles {
		id, _ := strconv.Atoi(params["id"])
		if vehicle.Id == id {
			json.NewEncoder(w).Encode(vehicle)
		}
	}
}

func CreateCar(w http.ResponseWriter, r *http.Request) {
	car := new(Vehicle)
	_ = json.NewDecoder(r.Body).Decode(car)
	car.Id = len(Vehicles) + 1
	Vehicles = append(Vehicles, *car)
	w.WriteHeader(http.StatusCreated)
	json.NewEncoder(w).Encode(car)
}

func UpdateCar(w http.ResponseWriter, r *http.Request) {
	params := mux.Vars(r)
	for index, vehicle := range Vehicles {
		id, _ := strconv.Atoi(params["id"])
		if vehicle.Id == id {
			Vehicles = append(Vehicles[:index], Vehicles[index+1:]...)
			car := new(Vehicle)
			_ = json.NewDecoder(r.Body).Decode(car)
			car.Id = id
			Vehicles = append(Vehicles, *car)
			w.WriteHeader(http.StatusOK)
			json.NewEncoder(w).Encode(car)
		}
	}
}

func DeleteCar(w http.ResponseWriter, r *http.Request) {
	params := mux.Vars(r)
	for index, vehicle := range Vehicles {
		id, _ := strconv.Atoi(params["id"])
		if vehicle.Id == id {
			Vehicles = append(Vehicles[:index], Vehicles[index+1:]...)
		}
	}
}

func DeleteAllCars(w http.ResponseWriter, r *http.Request) {
	Vehicles = []Vehicle{}
}
