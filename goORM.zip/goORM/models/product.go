package models

type Product struct {
	PrId    int    `json:"pr_id"`
	PrName  string `json:"pr_name"`
	PrPrice float32    `json:"pr_price"`
}
