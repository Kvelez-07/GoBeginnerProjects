package main

import (
	"goORM/connection"
)

func main() {
	connection.InitDB()
}
