package connection

import (
	"fmt"
	"goORM/models"
	"log"

	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"gorm.io/gorm/schema"
)

// InitDB initializes the database connection
func InitDB() {
	conn, err := GetConnectionString("localhost", "kvelez", "kevito0307", "go_postgres", "5432")
	if err != nil {
		log.Fatal(err)
	}
	fmt.Println("connected")
	queryProducts(conn)
	queryProductById(conn, 2)
	rawQuery(conn)
	registerProduct(conn)
	updateProduct(conn, 1)
	deleteProduct(conn, 3)
	_ = conn
}

// GetConnectionString returns a gorm.DB instance with the given connection parameters
func GetConnectionString(host, username, password, dbname, port string) (*gorm.DB, error) {
	dsn := fmt.Sprintf("host=%s user=%s password=%s dbname=%s port=%s sslmode=disable", host, username, password, dbname, port)
	return gorm.Open(postgres.Open(dsn), &gorm.Config{NamingStrategy: schema.NamingStrategy{SingularTable: true}}) // enable singular table
}

// registerProduct registers a product in the database
func registerProduct(conn *gorm.DB) {
	mouse := models.Product{PrId: 2, PrName: "Mouse", PrPrice: 500}
	microphone := models.Product{PrId: 3, PrName: "Microphone", PrPrice: 5000}
	rs := conn.Create([]models.Product{mouse, microphone})

	if rs.Error != nil {
		log.Fatal(rs.Error)
	}
}

func queryProducts(conn *gorm.DB) {
	products := []models.Product{}
	if err := conn.Find(&products).Error; err != nil {
		log.Fatal(err)
	}
	for _, p := range products {
		fmt.Println(p)
	}
}

func queryProductById(conn *gorm.DB, id int) {
	product := models.Product{}
	if err := conn.Where("pr_id = ?", id).First(&product).Error; err != nil {
		log.Fatal(err)
	}
	fmt.Println(product)
}

func updateProduct(conn *gorm.DB, id int) {
	product := models.Product{PrName: "Keyboard", PrPrice: 2000}
	rs := conn.Where("pr_id = ?", id).Updates(&product)

	if rs.Error != nil {
		log.Fatal(rs.Error)
	}
}

func deleteProduct(conn *gorm.DB, id int) {
	rs := conn.Where("pr_id = ?", id).Delete(&models.Product{})
	if rs.Error != nil {
		log.Fatal(rs.Error)
	}
}

func rawQuery(conn *gorm.DB) {
	products := []models.Product{}
	rs := conn.Raw("select * from products where pr_id = ?", 1).Scan(&products)
	if rs.Error != nil {
		log.Fatal(rs.Error)
		return
	}
	if err := rs.Scan(&products).Error; err != nil {
		log.Fatal(err)
		return
	}
	for _, p := range products {
		fmt.Println(p)
	}
}
