package main

import (
	"html/template"
	"log"
	"net/http"
)

type Todo struct {
	Id      int
	Message string
}

func main() {
	data := map[string][]Todo{
		"Todos": {
			{Id: 1, Message: "Learn Go"},
			{Id: 2, Message: "Learn Docker"},
			{Id: 3, Message: "Learn Kubernetes"},
			{Id: 4, Message: "Learn ASP.NET Core"},
		},
	}

	todosHandler := func(w http.ResponseWriter, r *http.Request) {
		templateView := template.Must(template.ParseFiles("index.html"))
		templateView.Execute(w, data)
	}

	addTodoHandler := func(w http.ResponseWriter, r *http.Request) {
		message := r.PostFormValue("message")
		todo := Todo{Id: len(data["Todos"]) + 1, Message: message}
		data["Todos"] = append(data["Todos"], todo)

		templateView := template.Must(template.ParseFiles("index.html"))
		templateView.ExecuteTemplate(w, "todo-list-element", todo)
	}

	http.HandleFunc("/", todosHandler)
	http.HandleFunc("/add-todo", addTodoHandler)
	log.Println("server start at http://localhost:8000")
	log.Fatal(http.ListenAndServe(":8000", nil))
}
