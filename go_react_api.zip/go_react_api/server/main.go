package main

import (
	"fmt"
	"log"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/cors"
)

type Todo struct {
	Id    int    `json:"id"`
	Title string `json:"title"`
	Done  bool   `json:"done"`
	Body  string `json:"body"`
}

func main() {
	app := fiber.New()

	app.Use(cors.New(cors.Config{
		AllowOrigins: "http://localhost:3000",
		AllowHeaders: "Origin, Content-Type, Accept",
	}))

	todos := []Todo{} // slice of todos
	fmt.Println("Server listening at http://localhost:3000")

	app.Get("/", func(c *fiber.Ctx) error {
		return c.SendString("Hello, World!")
	})

	app.Get("/api/todos", func(c *fiber.Ctx) error {
		return c.JSON(todos) // return todos
	})

	app.Patch("/api/todos/:id/done", func(c *fiber.Ctx) error {
		id, err := c.ParamsInt("id") // get id from url params
		if err != nil {
			return c.Status(500).SendString(err.Error()) // return 500 if error
		}
		for i, t := range todos {
			if t.Id == id {
				todos[i].Done = true // set done to true
				break
			}
		}
		return c.JSON(todos) // return todos
	})

	app.Post("/api/todos", func(c *fiber.Ctx) error {
		todo := &Todo{} // create a new todo
		if err := c.BodyParser(todo); err != nil {
			return err
		}
		todo.Id = len(todos) + 1     // increment id
		todos = append(todos, *todo) // append todo to todos
		return c.JSON(todos)         // return todos
	})

	app.Delete("/api/todos/:id", func(c *fiber.Ctx) error {
		id, err := c.ParamsInt("id") // get id from url params
		if err != nil {
			return c.Status(500).SendString(err.Error()) // return 500 if error
		}
		for i, t := range todos {
			if t.Id == id {
				todos = append(todos[:i], todos[i+1:]...) // remove todo from todos
				break
			}
		}
		return c.JSON(todos) // return todos
	})

	log.Fatal(app.Listen(":3000"))
}
