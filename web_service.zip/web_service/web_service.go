package main

import (
	"fmt"
	"log"
	"net/http"
)

func main() {
	http.HandleFunc("/", handler)                        // set router
	http.HandleFunc("/contact", contactHandler)		  // set router
	
	log.Println("server start at http://localhost:8080") // write message
	log.Fatal(http.ListenAndServe(":8080", nil))         // set listen port
}

func handler(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintf(w, "Hello World!") // write Response
}

func contactHandler(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintf(w, "Contact Page!") // write Response
}
