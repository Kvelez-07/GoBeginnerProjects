package main

import (
	"github.com/jmoiron/sqlx"

	_ "github.com/lib/pq" // Import the PostgreSQL driver
)

// Query the database to create the table
// CREATE TABLE books (
//     id SERIAL PRIMARY KEY,
//     name TEXT NOT NULL,
//     description TEXT NOT NULL,
//     author TEXT NOT NULL
// );

var DB *sqlx.DB

func initDB() error {
	var err error
	DB, err = sqlx.Open("postgres", "host=localhost port=5432 user=kvelez password=kevito0307 dbname=go_books sslmode=disable")
	if err != nil {
		return err
	}
	// Ensure the database is reachable
	err = DB.Ping()
	if err != nil {
		return err
	}
	return nil
}

func killDB() error {
	return DB.Close()
}
