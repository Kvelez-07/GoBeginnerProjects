package main

import (
	"fmt"
	"log"
	"net/http"

	"github.com/go-chi/chi/v5"
	"github.com/go-chi/chi/v5/middleware"
)

func main() {
	err := initDB()
	if err != nil {
		log.Fatalf("failed to initialize database: %v", err)
		return
	}
	defer func() {
		if err := killDB(); err != nil {
			log.Printf("failed to close database connection: %v", err)
		}
	}()

	r := chi.NewRouter()
	r.Use(middleware.Logger)

	r.Get("/", func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("Hello World"))
	})

	r.Post("/books", create)
	r.Get("/books", getAll)
	r.Get("/books/{id}", get)
	r.Put("/books/{id}", update)
	r.Delete("/books/{id}", delete)

	fmt.Println("Server listening at http://localhost:3000")
	if err := http.ListenAndServe("localhost:3000", r); err != nil {
		log.Fatalf("failed to start server: %v", err)
	}
}
