package main

import (
	"encoding/json"
	"log"
	"net/http"
	"strconv"

	"github.com/go-chi/chi/v5"
)

type Book struct {
	Id          int    `json:"id"`
	Name        string `json:"name"`
	Description string `json:"description"`
	Author      string `json:"author"`
}

// Book DTO (Incremental PK)
type CreateBookBody struct {
	Name        string `json:"name"`
	Description string `json:"description"`
	Author      string `json:"author"`
}

func create(w http.ResponseWriter, r *http.Request) {
	body := CreateBookBody{}
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		http.Error(w, "Invalid request payload", http.StatusBadRequest)
		log.Printf("failed to parse request body: %v", err)
		return
	}

	if err := DB.QueryRow("INSERT INTO books (name, description, author) VALUES ($1, $2, $3)", body.Name, body.Description, body.Author).Err(); err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
}

func getAll(w http.ResponseWriter, r *http.Request) {
	books := []Book{}
	if err := DB.Select(&books, "SELECT * FROM books"); err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	j, err := json.Marshal(books)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		log.Printf("failed to fetch books: %v", err)
		return
	}
	w.Write(j)
}

func get(w http.ResponseWriter, r *http.Request) {
	bookId, err := strconv.Atoi(chi.URLParam(r, "id"))
	if err != nil {
		http.Error(w, "Invalid book ID", http.StatusBadRequest)
		log.Printf("failed to parse book ID: %v", err)
		return
	}

	book := Book{}

	if err := DB.Get(&book, "SELECT * FROM books WHERE id = $1", bookId); err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	j, err := json.Marshal(book)
	if err != nil {
		http.Error(w, "Failed to fetch book", http.StatusInternalServerError)
		log.Printf("failed to marshal book: %v", err)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	w.Write(j)
}

func update(w http.ResponseWriter, r *http.Request) {
	bookId, err := strconv.Atoi(chi.URLParam(r, "id"))
	if err != nil {
		http.Error(w, "Invalid book ID", http.StatusBadRequest)
		log.Printf("failed to parse book ID: %v", err)
		return
	}
	body := CreateBookBody{}
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		http.Error(w, "Invalid request payload", http.StatusBadRequest)
		log.Printf("failed to parse request body: %v", err)
		return
	}
	if err := DB.QueryRow("UPDATE books SET name = $1, description = $2, author = $3 WHERE id = $4", body.Name, body.Description, body.Author, bookId).Err(); err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
}

func delete(w http.ResponseWriter, r *http.Request) {
	bookId, err := strconv.Atoi(chi.URLParam(r, "id"))
	if err != nil {
		http.Error(w, "Invalid book ID", http.StatusBadRequest)
		log.Printf("failed to parse book ID: %v", err)
		return
	}
	if err := DB.QueryRow("DELETE FROM books WHERE id = $1", bookId).Err(); err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
}
