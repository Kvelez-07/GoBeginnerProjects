package main

import (
	"fmt"
	"log"
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
)

type ToDo struct {
	Id    int    `json:"id"`
	Title string `json:"title"`
	Done  bool   `json:"done"`
}

var todos = []ToDo{
	{Id: 1, Title: "Task 1", Done: false},
	{Id: 2, Title: "Task 2", Done: true},
	{Id: 3, Title: "Task 3", Done: false},
}

func main() {
	log.Println("Listening at http://localhost:8080")
	router := gin.Default()

	// GET request
	router.GET("/", handleHello)
	router.GET("/todos/:id", getToDoById)
	router.GET("/todos", getToDos)

	// POST request
	router.POST("/todos", addToDo)

	// PUT request
	router.PUT("/todos/:id", toggleToDoStatus)

	// DELETE request
	router.DELETE("/todos/:id", deleteToDo)

	router.Run(":8080") // Only provide the port number
}

func getToDo(id string) (*ToDo, error) {
	for _, t := range todos {
		if strconv.Itoa(t.Id) == id {
			return &t, nil
		}
	}
	return nil, fmt.Errorf("todo not found")
}

func getToDoById(c *gin.Context) {
	id := c.Param("id")
	todo, err := getToDo(id)
	if err != nil {
		c.IndentedJSON(http.StatusNotFound, gin.H{"message": "todo not found"})
		return
	}
	c.IndentedJSON(http.StatusOK, todo)
}

func getToDos(c *gin.Context) {
	c.IndentedJSON(http.StatusOK, todos)
}

func addToDo(c *gin.Context) {
	newToDo := ToDo{}
	if err := c.BindJSON(&newToDo); err != nil {
		c.IndentedJSON(http.StatusBadRequest, gin.H{"message": "invalid request"})
		return
	}
	todos = append(todos, newToDo)
	c.IndentedJSON(http.StatusCreated, newToDo)
}

func toggleToDoStatus(c *gin.Context) {
	id := c.Param("id")
	todo, err := getToDo(id)
	if err != nil {
		c.IndentedJSON(http.StatusNotFound, gin.H{"message": "todo not found"})
		return
	}
	for i, t := range todos {
		if t.Id == todo.Id {
			todos[i].Done = !todos[i].Done
			c.IndentedJSON(http.StatusOK, todos[i])
			return
		}
	}
}

func deleteToDo(c *gin.Context) {
	id := c.Param("id")
	for i, t := range todos {
		if strconv.Itoa(t.Id) == id {
			todos = append(todos[:i], todos[i+1:]...)
			c.IndentedJSON(http.StatusOK, gin.H{"message": "todo deleted"})
			return
		}
	}
	c.IndentedJSON(http.StatusNotFound, gin.H{"message": "todo not found"})
}

func handleHello(c *gin.Context) {
	c.IndentedJSON(http.StatusOK, gin.H{"message": "Hello World"})
}
