package main

import (
	"fmt"
	"math/rand"
	"strings"
	"time"
)

func main() {

	choices := []string{"Rock", "Paper", "Scissors"}
	choice := ""
	computerChoice := ""
	fmt.Print("Enter choice: (Rock, Paper, Scissors)\n => ")
	fmt.Scan(&choice)
	choice = strings.ToUpper(choice[0:1]) + strings.ToLower(choice[1:])

	source := rand.NewSource(time.Now().UnixNano())
	random := rand.New(source)
	computerChoice = choices[random.Intn(len(choices))]

	fmt.Println("Player chooses: ", choice)
	fmt.Println("Computer chooses: ", computerChoice)

	switch {
	case choice == computerChoice:
		fmt.Println("Tie!")
	case (choice == "Rock" && computerChoice == "Scissors") || (choice == "Paper" && computerChoice == "Rock") || (choice == "Scissors" && computerChoice == "Paper"):
		fmt.Println("Player wins!")
	case (computerChoice == "Rock" && choice == "Scissors") || (computerChoice == "Paper" && choice == "Rock") || (computerChoice == "Scissors" && choice == "Paper"):
		fmt.Println("Computer wins!")
	default:
		fmt.Println("Invalid input")
	}
}
