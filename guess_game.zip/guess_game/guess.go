package main

import (
	"fmt"
	"math/rand"
	"time"
)

func main() {
	gameLoop()
}

func getRandomNumber() int {
	// Create a new rand.Rand instance with a unique seed
	source := rand.NewSource(time.Now().UnixNano())
	random := rand.New(source)
	return random.Intn(11) // Get a number between 0 and 10
}

func getUserGuess() int {
	var guess int
	fmt.Println("Guess a number between 0 and 10")
	_, err := fmt.Scan(&guess) // Get user guess

	if err != nil {
		fmt.Println("Error reading input:", err)
		return 0
	}
	return guess
}

func checkGuess(guess int, secret int) bool {
	if guess == secret {
		fmt.Println("You guessed it!")
		return true
	} else if guess < secret {
		fmt.Println("Too low")
	} else {
		fmt.Println("Too high")
	}
	return false
}

func gameLoop() {
	attempts := 3
	secret := getRandomNumber()
	fmt.Println("A secret number has been generated. You have 3 attempts to guess it.")
	
	for attempts > 0 {
		guess := getUserGuess()
		if checkGuess(guess, secret) {
			break
		}
		attempts--
		if attempts > 0 {
			fmt.Printf("Attempts left: %d\n", attempts)
		} else {
			fmt.Println("Game over. The secret number was:", secret)
		}
	}
}