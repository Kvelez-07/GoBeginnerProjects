package main

import (
	"fmt"
	"log"
	"os"
)

func main() {
	file, err := os.Open("notes.csv") // access

	if err != nil {
		log.Fatal(err)
	}

	data := make([]byte, 100) // read
	count, err := file.Read(data)

	if err != nil {
		log.Fatal(err)
	}

	// log.Println(string(data[:count]))
	fmt.Println(string(data[:count]))

	defer file.Close()
}
