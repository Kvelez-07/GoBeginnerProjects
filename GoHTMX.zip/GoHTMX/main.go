package main

import (
	"fmt"
	"html/template"
	"net/http"
)

type Movie struct {
	Title    string `json:"title"`
	Director string `json:"director"`
}

func main() {
	fmt.Println("Server running at http://localhost:8080")
	http.HandleFunc("/", hello)
	http.ListenAndServe(":8080", nil)
}

func hello(w http.ResponseWriter, r *http.Request) {
	tmpl := template.Must(template.ParseFiles("index.html"))
	movies := map[string][]Movie{
		"Movies": {
			{Title: "Casablanca", Director: "Michael Curtiz"},
			{Title: "Cool Hand Luke", Director: "Stuart Rosenberg"},
		},
	}
	if err := tmpl.Execute(w, movies); err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
	}
}
