package models

import "fmt"

type Task struct {
	Id        int    `json:"id"`
	Name      string `json:"name"`
	Completed bool   `json:"completed"`
}

func ReadTask(tasks []Task) {
	if len(tasks) == 0 {
		fmt.Println("No tasks found")
		return
	}
	for _, task := range tasks {
		fmt.Printf("%d. %s\n", task.Id, task.Name)
	}
}

func CreateTask(tasks []Task) {
	task := Task{}
	fmt.Print("Enter task name: ")
	fmt.Scan(&task.Name)
	task.Completed = false
	task.Id = len(tasks) + 1
	tasks = append(tasks, task)
	fmt.Println("Task created successfully")
	ReadTask(tasks)
}

func UpdateTask(tasks []Task) {
	taskId := 0
	fmt.Print("Enter task id: ")
	fmt.Scan(&taskId)
	if taskId < 1 || taskId > len(tasks) {
		fmt.Println("Invalid task id")
		return
	}
	task := &tasks[taskId-1]
	fmt.Print("Enter task name: ")
	fmt.Scan(&task.Name)
	fmt.Println("Task updated successfully")
	ReadTask(tasks)
}

func DeleteTask(tasks []Task) {
	taskId := 0
	fmt.Print("Enter task id: ")
	fmt.Scan(&taskId)
	if taskId < 1 || taskId > len(tasks) {
		fmt.Println("Invalid task id")
		return
	}
	tasks = append(tasks[:taskId-1], tasks[taskId:]...)
	fmt.Println("Task deleted successfully")
	ReadTask(tasks)
}

func CompleteTask(tasks []Task) {
	taskId := 0
	fmt.Print("Enter task id: ")
	fmt.Scan(&taskId)
	if taskId < 1 || taskId > len(tasks) {
		fmt.Println("Invalid task id")
		return
	}
	task := &tasks[taskId-1]
	task.Completed = true
	fmt.Println("Task completed successfully")
	ReadTask(tasks)
}
