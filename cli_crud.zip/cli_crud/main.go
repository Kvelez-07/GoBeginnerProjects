package main

import (
	"cli_crud/models"
	"encoding/json"
	"fmt"
	"io"
	"os"
)

func main() {
	file, err := os.OpenFile("models/task.json", os.O_RDONLY|os.O_CREATE, 0)
	if err != nil {
		panic(err)
	}
	defer file.Close()

	tasks := []models.Task{}

	info, err := file.Stat()
	if err != nil {
		panic(err)
	}

	if info.Size() != 0 {
		bytes, err := io.ReadAll(file)
		if err != nil {
			panic(err)
		}
		// 0101010 -> JSON
		err = json.Unmarshal(bytes, &tasks)
		if err != nil {
			panic(err)
		}
	} else {
		tasks = []models.Task{}
	}

	if len(os.Args) < 2 {
		actionPrompt()
		return
	}

	switch os.Args[1] {
	case "create":
		models.CreateTask(tasks)
	case "read":
		models.ReadTask(tasks)
	case "update":
		models.UpdateTask(tasks)
	case "delete":
		models.DeleteTask(tasks)
	case "complete":
		models.CompleteTask(tasks)
	default:
		actionPrompt()
	}
}

func actionPrompt() {
	fmt.Println("Shell actions: create, read, update, delete, complete")
}
