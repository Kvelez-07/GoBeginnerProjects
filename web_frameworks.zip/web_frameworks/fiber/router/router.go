package router

import (
	"fiber/handlers"

	"github.com/gofiber/fiber/v2"
)

func RegisterRoutes(f *fiber.App) {

	// api version path
	users := f.Group("/api/v1/users")

	// route doesn't require /users in the string because is a group
	users.Post("/", handlers.Create)
	users.Get("/", handlers.Read)
	users.Get("/:id", handlers.ReadByID)
	users.Put("/:id", handlers.Update)
	users.Delete("/:id", handlers.Delete)

}
