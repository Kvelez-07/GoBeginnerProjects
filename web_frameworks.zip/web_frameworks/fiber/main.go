package main

import (
	"fiber/handlers"
	"fiber/router"
	"fmt"
	"log"

	"github.com/gofiber/fiber/v2"
)

func main() {
	fmt.Println("Server listening at http://localhost:8080")
	app := fiber.New()
	app.Get("/", handlers.Handler)
	router.RegisterRoutes(app)
	log.Fatal(app.Listen(":8080"))
}
