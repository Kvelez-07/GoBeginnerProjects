package handlers

import (
	"fiber/models"
	"strconv"

	"github.com/gofiber/fiber/v2"
)

func Handler(c *fiber.Ctx) error {
	return c.SendString("Hello, World!")
}

func Create(c *fiber.Ctx) error {
	user := new(models.User)
	if err := c.BodyParser(user); err != nil {
		return c.Status(500).SendString(err.Error())
	}
	user.Id = len(models.Users) + 1
	models.Users = append(models.Users, *user)
	return c.JSON(user)
}

func Read(c *fiber.Ctx) error {
	return c.JSON(models.Users)
}

func ReadByID(c *fiber.Ctx) error {
	userId := c.Params("id")

	for _, user := range models.Users {
		id, err := strconv.Atoi(userId)
		if err != nil {
			return c.Status(500).SendString(err.Error())
		}
		if user.Id == id {
			return c.JSON(user)
		}
	}
	return c.Status(404).SendString("User not found")
}

func Update(c *fiber.Ctx) error {
	userId := c.Params("id")

	for i, user := range models.Users {
		id, err := strconv.Atoi(userId)
		if err != nil {
			return c.Status(500).SendString(err.Error())
		}
		if user.Id == id {
			models.Users = append(models.Users[:i], models.Users[i+1:]...)
			return c.JSON(user)
		}
	}
	return c.Status(404).SendString("User not found")
}

func Delete(c *fiber.Ctx) error {
	userId := c.Params("id")

	for i, user := range models.Users {
		id, err := strconv.Atoi(userId)
		if err != nil {
			return c.Status(500).SendString(err.Error())
		}
		if user.Id == id {
			models.Users = append(models.Users[:i], models.Users[i+1:]...)
			return c.SendString("User deleted")
		}
	}
	return c.Status(404).SendString("User not found")
}
