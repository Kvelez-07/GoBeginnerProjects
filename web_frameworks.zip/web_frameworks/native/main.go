package main

import (
	"fmt"
	"log"
	"net/http"
)

func main() {
	fmt.Println("Server listening at http://localhost:8080")
	http.HandleFunc("/", handleHello)
	log.Fatal(http.ListenAndServe(":8080", nil))
}

func handleHello(w http.ResponseWriter, r *http.Request) {
	w.Write([]byte("Hello, World!"))
}
