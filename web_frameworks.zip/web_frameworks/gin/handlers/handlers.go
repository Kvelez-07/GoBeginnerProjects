package handlers

import (
	"gin/models"
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
)

func HandlerHello(g *gin.Context) {
	g.JSON(200, gin.H{
		"message": "Hello, World!",
	})
}

func Handler(g *gin.Context) {
	g.JSON(200, gin.H{
		"message": "pong",
	})
}

func GetAllUsers(g *gin.Context) {
	g.JSON(http.StatusOK, models.Users)
}

func GetUserById(g *gin.Context) {
	userId := g.Param("id")
	id, err := strconv.Atoi(userId)
	if err != nil {
		g.String(http.StatusBadRequest, "Invalid user ID")
	}
	for _, user := range models.Users {
		if user.Id == id {
			g.JSON(http.StatusOK, user)
			return
		}
	}
	g.String(http.StatusNotFound, "User not found")
}

func CreateUser(g *gin.Context) {
	user := new(models.User)
	if err := g.Bind(user); err != nil {
		g.String(http.StatusBadRequest, "Invalid request payload")
		return
	}
	// Generate a new ID for the user
	user.Id = len(models.Users) + 1
	models.Users = append(models.Users, *user)
	g.JSON(http.StatusCreated, user)
}

func CompleteUpdateUser(g *gin.Context) {
	params := new(models.User)
	if err := g.Bind(params); err != nil {
		g.String(http.StatusBadRequest, "Invalid request payload")
		return
	}
	for i, user := range models.Users {
		if user.Id == params.Id {
			models.Users[i] = *params
			g.JSON(http.StatusOK, params)
			return
		}
	}
	g.String(http.StatusNotFound, "User not found")
}

func PartialUpdateUser(g *gin.Context) {
	userId := g.Param("id")
	id, err := strconv.Atoi(userId)
	if err != nil {
		g.String(http.StatusBadRequest, "Invalid user ID")
		return
	}

	params := new(models.User)
	if err := g.Bind(params); err != nil {
		g.String(http.StatusBadRequest, "Invalid request payload")
		return
	}
	for i, user := range models.Users {
		if user.Id == id {
			if params.Name != "" {
				models.Users[i].Name = params.Name
			}
			if params.Age != 0 {
				models.Users[i].Age = params.Age
			}
			models.Users[i].Active = params.Active
			g.JSON(http.StatusOK, models.Users[i])
			return
		}
	}
	g.String(http.StatusNotFound, "User not found")
}

func DeleteUser(g *gin.Context) {
	userId := g.Param("id")
	id, err := strconv.Atoi(userId)
	if err != nil {
		g.String(http.StatusBadRequest, "Invalid user ID")
		return
	}
	for i, user := range models.Users {
		if user.Id == id {
			models.Users = append(models.Users[:i], models.Users[i+1:]...)
			g.String(http.StatusOK, "User deleted")
			return
		}
	}
	g.String(http.StatusNotFound, "User not found")
}

func NotFound(g *gin.Context) {
	g.String(http.StatusNotFound, "Not found")
}
