package router

import (
	"gin/handlers"

	"github.com/gin-gonic/gin"
)

func RegisterRoutes(e *gin.Engine) {
	e.GET("/", handlers.HandlerHello)
	e.GET("/ping", handlers.Handler)

	// routes
	users := e.Group("/api/v1/users")

	// route doesn't require /users in the string because is a group
	users.GET("/", handlers.HandlerHello)
	users.GET("/", handlers.GetAllUsers)
	users.GET("/:id", handlers.GetUserById)
	users.POST("/", handlers.CreateUser)
	users.PATCH("/:id", handlers.PartialUpdateUser)
	users.PUT("/:id", handlers.CompleteUpdateUser)
	users.DELETE("/:id", handlers.DeleteUser)
}