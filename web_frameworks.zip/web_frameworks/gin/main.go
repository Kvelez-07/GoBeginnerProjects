package main

import (
	"fmt"
	"gin/router"

	"github.com/gin-gonic/gin"
)

func main() {
	fmt.Println("Server listening at http://localhost:8080")
	r := gin.Default()
	router.RegisterRoutes(r)
	r.Run()
}
