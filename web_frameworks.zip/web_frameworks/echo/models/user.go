package models

type User struct {
	Id     int    `json:"id"`
	Name   string `json:"name"`
	Age    int    `json:"age"`
	Active bool   `json:"active"`
}

var Users = []User{
	{Id: 1, Name: "John", Age: 20, Active: true},
	{Id: 2, Name: "Jane", Age: 21, Active: true},
	{Id: 3, Name: "Joe", Age: 22, Active: false},
	{Id: 4, Name: "Jill", Age: 23, Active: false},
}
