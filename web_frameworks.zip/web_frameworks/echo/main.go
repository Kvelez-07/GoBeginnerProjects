package main

import (
	"echo/router"
	"fmt"

	"github.com/labstack/echo/v4"
	"github.com/labstack/echo/v4/middleware"
)

func main() {
	fmt.Println("Server listening at http://localhost:8080")
	// instance
	e := echo.New()
	// middleware
	e.Use(middleware.Logger())
	// routes
	router.RegisterRoutes(e)
	// start server
	e.Logger.Fatal(e.Start(":8080"))
}
