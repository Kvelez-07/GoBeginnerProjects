package router

import (
	"echo/handlers"

	"github.com/labstack/echo/v4"
)

func RegisterRoutes(e *echo.Echo) {
	// api version path
	users := e.Group("/api/v1/users")

	// route doesn't require /users in the string because is a group
	users.GET("/", handlers.Handler)
	users.GET("/", handlers.GetAllUsers)
	users.GET("/:id", handlers.GetUserById)
	users.POST("/", handlers.CreateUser)
	users.PATCH("/:id", handlers.PartialUpdateUser)
	users.PUT("/:id", handlers.CompleteUpdateUser)
	users.DELETE("/:id", handlers.DeleteUser)
}
