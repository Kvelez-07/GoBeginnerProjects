package handlers

import (
	"echo/models"
	"net/http"
	"strconv"

	"github.com/labstack/echo/v4"
)

func Handler(c echo.Context) error {
	return c.String(http.StatusOK, "Hello, World!")
}

func GetAllUsers(c echo.Context) error {
	return c.JSON(http.StatusOK, models.Users)
}

func GetUserById(c echo.Context) error {
	userId := c.Param("id")
	id, err := strconv.Atoi(userId)
	if err != nil {
		return c.String(http.StatusBadRequest, "Invalid user ID")
	}
	for _, user := range models.Users {
		if user.Id == id {
			return c.JSON(http.StatusOK, user)
		}
	}
	return c.String(http.StatusNotFound, "User not found")
}

func CreateUser(c echo.Context) error {
	user := new(models.User)
	if err := c.Bind(user); err != nil {
		return c.String(http.StatusBadRequest, "Invalid request payload")
	}
	// Generate a new ID for the user
	user.Id = len(models.Users) + 1
	models.Users = append(models.Users, *user)
	return c.JSON(http.StatusCreated, user)
}

func CompleteUpdateUser(c echo.Context) error {
	params := new(models.User)
	if err := c.Bind(params); err != nil {
		return c.String(http.StatusBadRequest, "Invalid request payload")
	}
	for i, user := range models.Users {
		if user.Id == params.Id {
			models.Users[i] = *params
			return c.JSON(http.StatusOK, params)
		}
	}
	return c.String(http.StatusNotFound, "User not found")
}

func PartialUpdateUser(c echo.Context) error {
	userId := c.Param("id")
	id, err := strconv.Atoi(userId)
	if err != nil {
		return c.String(http.StatusBadRequest, "Invalid user ID")
	}

	params := new(models.User)
	if err := c.Bind(params); err != nil {
		return c.String(http.StatusBadRequest, "Invalid request payload")
	}

	for i, user := range models.Users {
		if user.Id == id {
			if params.Name != "" {
				models.Users[i].Name = params.Name
			}
			if params.Age != 0 {
				models.Users[i].Age = params.Age
			}
			models.Users[i].Active = params.Active
			return c.JSON(http.StatusOK, models.Users[i])
		}
	}
	return c.String(http.StatusNotFound, "User not found")
}

func DeleteUser(c echo.Context) error {
	userId := c.Param("id")
	id, err := strconv.Atoi(userId)
	if err != nil {
		return c.String(http.StatusBadRequest, "Invalid user ID")
	}

	for i, user := range models.Users {
		if user.Id == id {
			models.Users = append(models.Users[:i], models.Users[i+1:]...)
			return c.String(http.StatusOK, "User deleted")
		}
	}
	return c.String(http.StatusNotFound, "User not found")
}

func NotFound(c echo.Context) error {
	return c.String(http.StatusNotFound, "Not found")
}
