package main

import (
	"fmt"
	"strings"

	"github.com/alwindoss/morse"
)

func main() {
	fmt.Println(morseCode("Hello World"))
}

func morseCode(message string) string {
	h := morse.NewHacker()
	morseCode, _ := h.Encode(strings.NewReader(message))
	return string(morseCode)
}