package routes

import (
	"encoding/json"
	"go_orm/db"
	"go_orm/models"
	"net/http"

	"github.com/gorilla/mux"
)

func GetUsersHandler(w http.ResponseWriter, r *http.Request) {
	w.Write([]byte("Get all users"))
	users := []models.User{}
	db.DB.Find(&users)
	json.NewEncoder(w).Encode(&users)
}

func GetUserHandler(w http.ResponseWriter, r *http.Request) {
	w.Write([]byte("Get user by id"))
	user := models.User{}
	db.DB.First(&user, mux.Vars(r)["id"])
	if user.ID == 0 {
		w.WriteHeader(http.StatusNotFound)
		w.Write([]byte("User not found"))
	}
	json.NewEncoder(w).Encode(&user)
}

func PostUserHandler(w http.ResponseWriter, r *http.Request) {
	w.Write([]byte("Create user"))
	user := models.User{}
	json.NewDecoder(r.Body).Decode(&user)
	newUser := db.DB.Create(&user)
	err := newUser.Error
	if err != nil {
		w.WriteHeader(http.StatusBadRequest)
		w.Write([]byte(err.Error()))
	}
	json.NewEncoder(w).Encode(&user)
}

func PutUserHandler(w http.ResponseWriter, r *http.Request) {
	w.Write([]byte("Update user"))
	user := models.User{}
	db.DB.First(&user, mux.Vars(r)["id"])
	if user.ID == 0 {
		w.WriteHeader(http.StatusNotFound)
		w.Write([]byte("User not found"))
	}
	json.NewDecoder(r.Body).Decode(&user)
	db.DB.Save(&user)
	json.NewEncoder(w).Encode(&user)
}

func DeleteUserHandler(w http.ResponseWriter, r *http.Request) {
	w.Write([]byte("Delete user"))
	user := models.User{}
	db.DB.Delete(&user, mux.Vars(r)["id"])
	if user.ID == 0 {
		w.WriteHeader(http.StatusNotFound)
		w.Write([]byte("User not found"))
	}
	json.NewEncoder(w).Encode(&user)
}
