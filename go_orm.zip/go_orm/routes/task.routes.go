package routes

import (
	"encoding/json"
	"go_orm/db"
	"go_orm/models"
	"net/http"

	"github.com/gorilla/mux"
)

func GetTasksHandler(w http.ResponseWriter, r *http.Request) {
	w.Write([]byte("Get all tasks"))
	tasks := []models.Task{}
	db.DB.Find(&tasks)
	json.NewEncoder(w).Encode(&tasks)
}

func GetTaskHandler(w http.ResponseWriter, r *http.Request) {
	w.Write([]byte("Get task by id"))
	task := models.Task{}
	db.DB.First(&task, mux.Vars(r)["id"])
	if task.ID == 0 {
		w.WriteHeader(http.StatusNotFound)
		w.Write([]byte("Task not found"))
	}
	json.NewEncoder(w).Encode(&task)
}

func PostTaskHandler(w http.ResponseWriter, r *http.Request) {
	w.Write([]byte("Create task"))
	task := models.Task{}
	json.NewDecoder(r.Body).Decode(&task)
	newTask := db.DB.Create(&task)
	err := newTask.Error
	if err != nil {
		w.WriteHeader(http.StatusBadRequest)
		w.Write([]byte(err.Error()))
	}
	json.NewEncoder(w).Encode(&task)
}

func PutTaskHandler(w http.ResponseWriter, r *http.Request) {
	w.Write([]byte("Update task"))
	task := models.Task{}
	db.DB.First(&task, mux.Vars(r)["id"])
	if task.ID == 0 {
		w.WriteHeader(http.StatusNotFound)
		w.Write([]byte("Task not found"))
	}
	json.NewDecoder(r.Body).Decode(&task)
	db.DB.Save(&task)
	json.NewEncoder(w).Encode(&task)
}

func DeleteTaskHandler(w http.ResponseWriter, r *http.Request) {
	w.Write([]byte("Delete task"))
	task := models.Task{}
	db.DB.Delete(&task, mux.Vars(r)["id"])
	if task.ID == 0 {
		w.WriteHeader(http.StatusNotFound)
		w.Write([]byte("Task not found"))
	}
	json.NewEncoder(w).Encode(&task)
}
