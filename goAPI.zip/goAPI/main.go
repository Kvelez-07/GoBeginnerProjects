package main

import (
	"fmt"
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
)

type Book struct {
	Id       int    `json:"id"`
	Title    string `json:"title"`
	Author   string `json:"author"`
	Quantity int    `json:"quantity"`
}

var books = []Book{
	{Id: 1, Title: "Book 1", Author: "Author 1", Quantity: 10},
	{Id: 2, Title: "Book 2", Author: "Author 2", Quantity: 5},
	{Id: 3, Title: "Book 3", Author: "Author 3", Quantity: 20},
}

func main() {
	fmt.Println("Listening at http://localhost:8080")
	router := gin.Default()

	router.GET("/", handleHello)
	router.GET("/books", getBooks)
	router.GET("/books/:id", getBook)
	router.POST("/books", createBook)
	router.PUT("/books/:id", updateBook)
	router.DELETE("/books/:id", deleteBook)
	router.Run(":8080")
}

func handleHello(c *gin.Context) {
	c.IndentedJSON(http.StatusOK, gin.H{"message": "hello"})
}

func getBooks(c *gin.Context) {
	c.IndentedJSON(http.StatusOK, books)
}

func getBook(c *gin.Context) {
	id := c.Param("id")
	for _, a := range books {
		parsedId, err := strconv.Atoi(id)
		if err != nil {
			c.IndentedJSON(http.StatusBadRequest, gin.H{"message": "invalid id"})
			return
		}
		if a.Id == parsedId {
			c.IndentedJSON(http.StatusOK, a)
			return
		}
	}
	c.IndentedJSON(http.StatusNotFound, gin.H{"message": "book not found"})
}

func createBook(c *gin.Context) {
	newBook := Book{}
	if err := c.BindJSON(&newBook); err != nil {
		return
	}
	books = append(books, newBook)
	c.IndentedJSON(http.StatusCreated, newBook)
}

func updateBook(c *gin.Context) {
	id := c.Param("id")
	for i, a := range books {
		parsedId, err := strconv.Atoi(id)
		if err != nil {
			c.IndentedJSON(http.StatusBadRequest, gin.H{"message": "invalid id"})
			return
		}
		if a.Id == parsedId {
			books = append(books[:i], books[i+1:]...)
			if err := c.BindJSON(&a); err != nil {
				return
			}
			books = append(books, a)
			c.IndentedJSON(http.StatusOK, a)
			return
		}
	}
	c.IndentedJSON(http.StatusNotFound, gin.H{"message": "book not found"})
}

func deleteBook(c *gin.Context) {
	id := c.Param("id")
	for i, a := range books {
		parsedId, err := strconv.Atoi(id)
		if err != nil {
			c.IndentedJSON(http.StatusBadRequest, gin.H{"message": "invalid id"})
			return
		}
		if a.Id == parsedId {
			books = append(books[:i], books[i+1:]...)
			c.IndentedJSON(http.StatusOK, gin.H{"message": "book deleted"})
			return
		}
	}
	c.IndentedJSON(http.StatusNotFound, gin.H{"message": "book not found"})
}
