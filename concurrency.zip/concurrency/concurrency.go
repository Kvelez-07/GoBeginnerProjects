package main

import (
	"bufio"
	"fmt"
	"net/http"
	"strconv"
	"sync"
	"time"
)

var wg sync.WaitGroup

func main() {
	concurrency()
}

func hi(num int) {
	defer wg.Done() // This ensures Done() is called when the function completes
	fmt.Println("Hi", num)
}

func concurrency() {
	for i := 1; i <= 10; i++ {
		wg.Add(1)
		go hi(i)
		time.Sleep(1 * time.Millisecond) // Give a little time for the goroutine to start
	}
	wg.Wait() // Wait for all goroutines to complete
	fmt.Println("Done!")

	for i := 1; i <= 10; i++ {
		wg.Add(1)
		go queryJson(i)
		time.Sleep(1 * time.Millisecond) // Give a little time for the goroutine to start
	}
	wg.Wait() // Wait for all goroutines to complete
	fmt.Println("Done!")
}

func queryJson(num int) {
	res, err := http.Get("https://jsonplaceholder.typicode.com/todos/" + strconv.Itoa(num))

	if err != nil {
		panic(err)
	}
	defer res.Body.Close()
	fmt.Println("Status: " + res.Status)

	scanner := bufio.NewScanner(res.Body)

	for i := 0; scanner.Scan(); i++ {
		fmt.Println(scanner.Text())
	}

	if err := scanner.Err(); err != nil {
		panic(err)
	}
}
