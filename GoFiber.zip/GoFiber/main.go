package main

import (
	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/logger"
)

type User struct {
	Name  string `json:"name"`
	Email string `json:"email"`
}

func main() {
	app := fiber.New()
	app.Use(logger.New())
	userApp := app.Group("/user")

	// GET
	userApp.Get("/", hello) // This route displays a greeting message.
	// Removing the redundant get route below.
	userApp.Get("/info", getUser) // This route gets a user.

	// POST
	userApp.Post("/", createUser)

	app.Listen(":3000")
}

func hello(c *fiber.Ctx) error {
	return c.SendString("Fiber API")
}

func getUser(c *fiber.Ctx) error {
	return c.JSON(&User{
		Name:  "John Doe",
		Email: "jKkxq@example.com",
	})
}

func createUser(c *fiber.Ctx) error {
	body := new(User)
	if err := c.BodyParser(body); err != nil {
		return c.Status(503).SendString(err.Error())
	}

	user := User{
		Name:  body.Name,
		Email: body.Email,
	}
	return c.Status(200).JSON(user)
}
