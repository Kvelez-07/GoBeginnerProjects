package main

import (
	"fmt"
	"net/http"
)

func main() {
	fmt.Println("Server running at http://localhost:8080")

	mux := http.NewServeMux()

	// Default
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprintf(w, "REST API")
	})

	// Custom GET
	mux.HandleFunc("GET /hello", hello)

	// Custom GET
	mux.HandleFunc("GET /comment/{id}", commentById)

	// Custom POST
	mux.HandleFunc("POST /comment", comment)

	if err := http.ListenAndServe(":8080", mux); err != nil {
		fmt.Println(err.Error())
	}
}

func hello(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintf(w, "Hello World!")
}

func comment(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintf(w, "You can comment!")
}

func commentById(w http.ResponseWriter, r *http.Request) {
	id := r.PathValue("id")
	fmt.Fprintf(w, "You can comment %s!", id)
}
