package main

import (
	"fmt"

	"github.com/gin-gonic/gin"
)

type User struct {
	Name  string `json:"name"`
	Email string `json:"email"`
}

var users []User // DB

func main() {
	fmt.Println("Server running at http://localhost:8080")

	router := gin.Default()

	// GET
	router.GET("/", hello)
	router.GET("/ping", pingPong)
	router.GET("/users", getUsers)

	// POST
	router.POST("/users", createUser)

	router.Run()
}

func hello(c *gin.Context) {
	c.JSON(200, gin.H{
		"message": "Hello World",
	})
}

func pingPong(c *gin.Context) {
	c.JSON(200, gin.H{
		"message": "pong",
	})
}

func getUsers(c *gin.Context) {
	c.JSON(200, gin.H{
		"users": users,
	})
}

func createUser(c *gin.Context) {
	user := User{}

	// Bind JSON input to the User struct
	if err := c.ShouldBindJSON(&user); err != nil {
		c.JSON(400, gin.H{"error": err.Error()})
		return
	}

	// Add the user to the list (simulate saving to a database)
	users = append(users, user)

	// Respond with the created user
	c.JSON(201, gin.H{
		"message": "User created successfully",
		"user":    user,
	})
}
