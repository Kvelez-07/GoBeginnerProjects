package main

import "fmt"

func main() {
	fmt.Println("Welcome to the Quiz Game!")

	name := ""
	age := 0
	answer := 0
	answer3 := 0
	score := 0
	questions := 2
	total := 0

	fmt.Println("What is your name? ")
	fmt.Scan(&name)

	fmt.Println("How old are you? ")
	fmt.Scan(&age)

	if age >= 18 {
		fmt.Printf("Hello, %s. You are eligible to play the game.\n", name)
	} else {
		fmt.Printf("Hello, %s. You are not eligible to play the game.\n", name)
	}

	fmt.Println("RTX 3080 vs RTX 3090, which one is better? RTX (#): ")
	fmt.Scan(&answer)

	if answer == 3090 {
		fmt.Println("You are correct!")
		score++
	} else {
		fmt.Println("You are wrong!")
	}

	fmt.Printf("How many cores does the Ryzen 9 5950X have? ")
	fmt.Scan(&answer3)

	if answer3 == 12 {
		fmt.Println("You are correct!")
		score++
	} else {
		fmt.Println("You are wrong!")
	}

	fmt.Printf("You got %d out of %d.\n", score, questions)
	total = (score * 100) / questions

	fmt.Printf("Your total is %d%%.\n", total)
}
