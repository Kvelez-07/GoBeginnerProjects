package models

type Task struct {
	Id     int    `json:"id"`
	Name   string `json:"name"`
	Status string `json:"status"`
}

type allTasks []Task

var Tasks = allTasks{
	{
		Id:     1,
		Name:   "Task 1",
		Status: "Pending",
	},
	{
		Id:     2,
		Name:   "Task 2",
		Status: "Pending",
	},
}