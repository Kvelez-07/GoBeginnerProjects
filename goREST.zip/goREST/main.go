package main

import (
	"encoding/json"
	"fmt"
	"goREST/models"
	"io"
	"log"
	"net/http"
	"strconv"

	"github.com/gorilla/mux"
)

func main() {
	// Print message
	fmt.Println("Listening at http://localhost:8000")
	// Routes
	router := mux.NewRouter().StrictSlash(true)
	router.HandleFunc("/", handleHello).Methods("GET")
	router.HandleFunc("/tasks/{id}", getTask).Methods("GET")
	router.HandleFunc("/tasks", getTasks).Methods("GET")
	// Create
	router.HandleFunc("/tasks", createTask).Methods("POST")
	// Update
	router.HandleFunc("/tasks/{id}", updateTask).Methods("PUT")
	// Delete
	router.HandleFunc("/tasks/{id}", deleteTask).Methods("DELETE")
	// Start server
	log.Fatal(http.ListenAndServe(":8000", router))
}

func handleHello(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintf(w, "Hello World!")
}

func getTask(w http.ResponseWriter, r *http.Request) {
	params := mux.Vars(r)
	for _, item := range models.Tasks {
		id, err := strconv.Atoi(params["id"])
		if err != nil {
			fmt.Fprintf(w, "Invalid ID")
			return
		}
		if item.Id == id {
			json.NewEncoder(w).Encode(item)
		}
	}
}

func getTasks(w http.ResponseWriter, r *http.Request) {
	json.NewEncoder(w).Encode(models.Tasks)
}

func createTask(w http.ResponseWriter, r *http.Request) {
	newTask := models.Task{}
	reqBody, err := io.ReadAll(r.Body)
	if err != nil {
		fmt.Fprintf(w, "Kindly enter data with the event title and description only in order to update")
	}
	json.Unmarshal(reqBody, &newTask)
	newTask.Id = len(models.Tasks) + 1
	models.Tasks = append(models.Tasks, newTask)
	w.WriteHeader(http.StatusCreated)
	json.NewEncoder(w).Encode(newTask)
}

func updateTask(w http.ResponseWriter, r *http.Request) {
	params := mux.Vars(r)
	for index, item := range models.Tasks {
		id, err := strconv.Atoi(params["id"])
		if err != nil {
			fmt.Fprintf(w, "Invalid ID")
			return
		}
		if item.Id == id {
			models.Tasks = append(models.Tasks[:index], models.Tasks[index+1:]...)
			var newTask models.Task
			reqBody, err := io.ReadAll(r.Body)
			if err == nil {
				json.Unmarshal(reqBody, &newTask)
			}
			newTask.Id = id
			models.Tasks = append(models.Tasks, newTask)
			json.NewEncoder(w).Encode(newTask)
		}
	}
}

func deleteTask(w http.ResponseWriter, r *http.Request) {
	params := mux.Vars(r)
	for index, item := range models.Tasks {
		id, err := strconv.Atoi(params["id"])
		if err != nil {
			fmt.Fprintf(w, "Invalid ID")
			return
		}
		if item.Id == id {
			models.Tasks = append(models.Tasks[:index], models.Tasks[index+1:]...)
			fmt.Fprintf(w, "The task with ID %v has been deleted successfully", id)
		}
	}
}
