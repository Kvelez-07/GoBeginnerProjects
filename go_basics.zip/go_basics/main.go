package main

import (
	"encoding/csv"
	"fmt"
	"log"
	"os"
	"time"
)

func main() {
	fmt.Println(Add(1, 2))
	fmt.Println(Sub(3, 4))
	fmt.Println(Mul(5, 6))
	fmt.Println(Div(7, 8))
	fmt.Println(Mod(9, 10))

	Struct()
	ForLoop()
	WhileLoop()
	Dictionary()
	// readCsvFile("notes.csv")

	go goRoutines("world")
	goRoutines("hello")

	ch := make(chan int)
	go channels([]int{1, 2, 3}, ch)
	fmt.Println(<-ch)
}

func channels(arr []int, c chan int) {
	sum := 0
	for _, v := range arr {
		sum += v
	}
	c <- sum
}

func goRoutines(s string) {
	for i := 0; i < 5; i++ {
		time.Sleep(100 * time.Millisecond)
		fmt.Println(s)
	}
}

func readCsvFile(filePath string) [][]string {
	file, err := os.Open(filePath)
	if err != nil {
		log.Fatal("Error when opening file: ", err)
	}
	defer file.Close()

	reader := csv.NewReader(file)
	data, err := reader.ReadAll()
	if err != nil {
		log.Fatal("Error during read file: ", err)
	}
	return data
}

func Struct() {
	type Computer struct {
		Id       int     `json:"id"`
		Name     string  `json:"name"`
		Price    float32 `json:"price"`
		Brand    string  `json:"brand"`
		Vendor   string  `json:"vendor"`
		Quantity int     `json:"quantity"`
	}
	comp := Computer{
		Id:       1,
		Name:     "Laptop",
		Price:    1000.00,
		Brand:    "Dell",
		Vendor:   "Dell",
		Quantity: 10,
	}
	fmt.Println(comp)
}

func Dictionary() {
	dict := map[int]string{
		1: "Music",
		2: "Math",
		3: "Science",
		4: "History",
		5: "Geography",
	}
	fmt.Println(dict)
}

func ForLoop() {
	nums := []int{1, 2, 3, 4, 5}
	for _, n := range nums {
		if n%2 == 0 {
			fmt.Println(n, "is even")
		} else {
			fmt.Println(n, "is odd")
		}
	}
}

func WhileLoop() {
	nums := []int{1, 2, 3, 4, 5}
	i := 0
	for _, n := range nums {
		if n%2 == 0 {
			fmt.Println(n, "is even")
		} else {
			fmt.Println(n, "is odd")
		}
		i++
	}
}

func Add(x, y int) int {
	return x + y
}

func Sub(x, y int) int {
	return x - y
}

func Mul(x, y int) int {
	return x * y
}

func Div(x, y int) int {
	if y == 0 {
		panic("cannot divide by zero")
	}
	return x / y
}

func Mod(x, y int) int {
	return x % y
}
