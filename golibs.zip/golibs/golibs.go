package main

import (
	"fmt"
	"io"
	"math/rand"
	"net/http"
	"time"

	"github.com/xeonx/timeago"
)

func main() {
	fmt.Println(jsonQuery())
	fmt.Println(getRandomNumber())
	fmt.Println(timeagoQuery())
}

func jsonQuery() (string, string) {
	res, err := http.Get("https://jsonplaceholder.typicode.com/users/1")

	if err != nil {
		fmt.Println(err)
	}

	data, _ := io.ReadAll(res.Body)
	defer res.Body.Close()
	return string("\nStatus-Code: " + res.Status), string("\n" + string(data))
}

func getRandomNumber() (string, int) {
	// Create a new rand.Rand instance with a unique seed
	source := rand.NewSource(time.Now().UnixNano())
	random := rand.New(source)
	return "\nRandom number:", random.Intn(11) // Get a number between 0 and 10
}

func timeagoQuery() string {
	t := time.Now().Add(60 * time.Second)
	s := timeago.English.Format(t)
	return string("\nExecution time: " + s)
}
