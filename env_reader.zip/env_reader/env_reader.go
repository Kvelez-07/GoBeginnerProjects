package main

import (
	"env_reader/envs"
	"fmt"
)

func main() {
	v := envs.Get("API_KEY", "default")
	fmt.Println(v)
}
