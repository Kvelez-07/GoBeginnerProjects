package envs

import (
	"log"
	"os"

	"github.com/joho/godotenv"
)

func init() {
	if err := godotenv.Load(); err != nil { // searches .env file
		log.Fatal("Error loading .env file")
	}
}

func Get(key, defaultVal string) string {
	val, ok := os.LookupEnv(key)

	if !ok {
		return defaultVal
	}

	log.Println("key: " + key + " value: " + val)
	return val
}
